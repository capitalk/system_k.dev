#include "ClientHeartbeatMessage.h"

namespace itch
{

ClientHeartbeatMessage::ClientHeartbeatMessage()
        : MessageBase ( TYPE, true )
{
}

}
