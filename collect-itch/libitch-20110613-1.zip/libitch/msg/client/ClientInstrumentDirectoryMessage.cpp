#include "ClientInstrumentDirectoryMessage.h"

namespace itch
{

ClientInstrumentDirectoryMessage::ClientInstrumentDirectoryMessage()
        : MessageBase ( TYPE )
{
}

}
