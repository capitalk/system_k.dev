#include "ClientLogoutMessage.h"

namespace itch
{

ClientLogoutMessage::ClientLogoutMessage()
        : MessageBase ( TYPE )
{
}

}
